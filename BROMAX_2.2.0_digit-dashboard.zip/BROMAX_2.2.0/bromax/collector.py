import asyncio, json, logging, time
from datetime import datetime, timezone
from decimal import Decimal
from threading import Lock
import websockets
from .digits import extract_last_digit, quote_precision, QuotePrecisionError
from .strategies import candidate_strategies, ForecastContext
from .proposals import ProposalClient, ProposalUnavailable
from .paperbot import PaperBot

log=logging.getLogger("bromax.collector")

class MarketCollector:
    def __init__(self, settings, store, paperbot=None):
        self.settings=settings; self.store=store; self.paperbot=paperbot; self.last_received={}; self.errors=[]
        self.proposals=ProposalClient(settings.ws_url,settings.currency,settings.proposal_timeout_seconds)
        self.proposal_semaphore=asyncio.Semaphore(3)
        self.quote_tasks=set()
        self.cumulative_counts={symbol:list(store.digit_counts(symbol)) for symbol in settings.symbols}
        self.strategies=candidate_strategies()
        self._status_lock=Lock()
        self.connection_status="DISCONNECTED"
        self.connection_started_monotonic=None
        self.reconnect_count=0
        self.connection_error=None
        self._symbol_status={
            symbol:{
                "subscription_status":"NOT_SUBSCRIBED",
                "subscription_count":0,
                "received_ticks":0,
                "processed_ticks":0,
                "duplicate_ticks":0,
                "invalid_ticks":0,
                "out_of_order_ticks":0,
                "missing_tick_count":0,
                "history_seeded_ticks":0,
                "analysis_status":"WAITING_FOR_DATA",
                "analysis_runs":0,
                "strategy_status":"WAITING_FOR_DATA",
                "strategy_runs":0,
                "signal_generation_status":"WAITING_FOR_DATA",
                "signals_generated":0,
                "last_tick_epoch":None,
                "last_tick_id":None,
                "last_analysis_at":None,
                "last_signal_at":None,
                "last_signal_epoch":None,
                "last_error":None,
                "processing_errors":0,
            }
            for symbol in settings.symbols
        }

    def _record_error(self, message, symbol=None):
        self.errors.append(str(message))
        if len(self.errors)>100: del self.errors[:-100]
        with self._status_lock:
            if symbol in self._symbol_status:
                status=self._symbol_status[symbol]
                status["last_error"]=str(message)
                status["processing_errors"]+=1

    def _update_symbol_status(self, symbol, **values):
        with self._status_lock:
            self._symbol_status[symbol].update(values)

    def _increment_symbol_status(self, symbol, key, amount=1):
        with self._status_lock:
            status=self._symbol_status[symbol]
            status[key]+=amount

    def _set_connection_status(self, status, error=None, reconnect=False):
        now=datetime.now(timezone.utc).isoformat()
        with self._status_lock:
            self.connection_status=status
            self.connection_error=error
            if reconnect:
                self.reconnect_count+=1
            for symbol_status in self._symbol_status.values():
                symbol_status["connection_status"]=status
                if status in {"CONNECTING","RECONNECTING","DISCONNECTED","ERROR"}:
                    symbol_status["subscription_status"]="NOT_SUBSCRIBED"
                if status=="CONNECTED":
                    symbol_status["connected_at"]=now
                    symbol_status["last_error"]=None
                elif error:
                    symbol_status["last_error"]=error

    def operational_status(self, symbol):
        if symbol not in self._symbol_status:
            raise KeyError(symbol)
        with self._status_lock:
            result=dict(self._symbol_status[symbol])
            result["connection_status"]=self.connection_status
            result["reconnect_count"]=self.reconnect_count
            result["connection_error"]=self.connection_error
        received=self.last_received.get(symbol)
        age=max(0.0,time.time()-received) if received is not None else None
        result["freshness_seconds"]=round(age,3) if age is not None else None
        result["data_status"]=(
            "NO DATA" if age is None else
            "STALE" if age>self.settings.max_data_age_seconds else
            "RECEIVING DATA"
        )
        if result["connection_status"]=="RECONNECTING":
            result["pipeline_status"]="RECONNECTING"
        elif result.get("last_error"):
            result["pipeline_status"]="ERROR"
        elif result["data_status"]=="STALE":
            result["pipeline_status"]="STALE DATA"
        elif result["subscription_status"]!="SUBSCRIBED":
            result["pipeline_status"]=result["connection_status"]
        elif result["signal_generation_status"]=="GENERATING SIGNALS":
            result["pipeline_status"]="GENERATING SIGNALS"
        elif result["analysis_status"]=="ANALYZING":
            result["pipeline_status"]="ANALYZING"
        else:
            result["pipeline_status"]="RECEIVING DATA"
        return result

    def _seed_history(self, symbol, history, pip_size):
        """Persist a Deriv ticks_history response without generating retrospective forecasts."""
        prices=history.get("prices") or []
        times=history.get("times") or []
        precision=quote_precision(pip_size)
        if len(prices)!=len(times):
            raise ValueError(f"Historical seed arrays have mismatched lengths for {symbol}")
        inserted=0
        ordered=sorted(zip(times,prices),key=lambda item:int(item[0]))
        for epoch,price in ordered:
            epoch=int(epoch)
            quote_text,digit=extract_last_digit(price,precision)
            if digit is not None and self.store.add_tick(symbol,epoch,quote_text,precision,digit) is not None:
                inserted += 1
        self._increment_symbol_status(symbol,"history_seeded_ticks",inserted)
        return inserted
    async def _handle_tick(self, tick, symbol_hint=None):
        symbol=tick.get("symbol") or symbol_hint
        if symbol not in self.settings.symbols: raise ValueError(f"Unexpected symbol {symbol!r}")
        self._increment_symbol_status(symbol,"received_ticks")
        self._update_symbol_status(symbol,subscription_status="SUBSCRIBED")
        try:
            if "quote" not in tick or "epoch" not in tick or "pip_size" not in tick:
                raise ValueError("Tick missing quote/epoch/pip_size; refusing to infer")
            epoch=int(tick["epoch"])
            precision=quote_precision(tick["pip_size"])
            quote_text,digit=extract_last_digit(tick["quote"],precision)
            if digit is None: raise ValueError(f"Symbol {symbol} has no displayed decimal digit for MATCH contracts")
        except (QuotePrecisionError,ValueError,TypeError):
            self._increment_symbol_status(symbol,"invalid_ticks")
            raise
        previous=self.store.history(symbol,limit=1)
        previous_epoch=int(previous[-1]["epoch"]) if previous else None
        if previous_epoch is not None and epoch<previous_epoch:
            self._increment_symbol_status(symbol,"out_of_order_ticks")
            return False
        if previous_epoch is not None and epoch==previous_epoch:
            self._increment_symbol_status(symbol,"duplicate_ticks")
            return False
        if previous_epoch is not None and epoch>previous_epoch+1:
            self._increment_symbol_status(symbol,"missing_tick_count",epoch-previous_epoch-1)
        tick_id=self.store.add_tick(symbol,epoch,quote_text,precision,digit,tick.get("id"))
        if tick_id is None:
            self._increment_symbol_status(symbol,"duplicate_ticks")
            return False
        self.last_received[symbol]=time.time()
        self._increment_symbol_status(symbol,"processed_ticks")
        self._update_symbol_status(
            symbol,
            last_error=None,
            last_tick_epoch=int(tick["epoch"]),
            last_tick_id=tick_id,
            analysis_status="WAITING_FOR_HISTORY",
            strategy_status="WAITING_FOR_HISTORY",
            signal_generation_status="WAITING_FOR_HISTORY",
        )
        self.cumulative_counts[symbol][digit] += 1
        # First score prior forecasts with this newly arrived tick; then forecast from history ending here.
        self.store.score_open_forecasts(symbol,tick_id,int(tick["epoch"]),digit)
        self.store.settle_duration_contracts(symbol,tick_id,int(tick["epoch"]),digit)
        history=self.store.history(symbol,limit=1000)
        digits=tuple(int(r["digit"]) for r in history)
        if len(digits)<self.settings.min_history_ticks:
            return True
        latest=history[-1]
        ctx=ForecastContext(symbol,int(latest["id"]),int(latest["epoch"]),digits,tuple(self.cumulative_counts[symbol]))
        self._update_symbol_status(
            symbol,
            analysis_status="ANALYZING",
            strategy_status="ANALYZING",
            signal_generation_status="GENERATING SIGNALS",
        )
        self._increment_symbol_status(symbol,"analysis_runs")
        forecasts=[s.forecast(ctx) for s in self.strategies]
        # Freeze all forecasts synchronously before returning to the stream reader.
        # Quote requests run in background and are separately timestamped append-only events.
        forecast_rows=[]
        for f in forecasts:
            seq=self.store.append_forecast(symbol,f,tick_id,int(tick["epoch"]),None,self.settings.paper_stake,None,"PAYOUT_PENDING")
            forecast_rows.append((f,seq))
        generated_at=datetime.now(timezone.utc).isoformat()
        self._update_symbol_status(
            symbol,
            analysis_status="ANALYZED",
            strategy_status="PROCESSED",
            signal_generation_status="GENERATED" if forecasts else "NO SIGNALS",
            last_analysis_at=generated_at,
            last_signal_at=generated_at if forecasts else None,
            last_signal_epoch=int(tick["epoch"]) if forecasts else None,
        )
        self._increment_symbol_status(symbol,"strategy_runs",len(forecasts))
        self._increment_symbol_status(symbol,"signals_generated",len(forecasts))
        if len(self.quote_tasks) >= self.settings.max_pending_quote_tasks:
            self._record_error("Proposal queue full; forecast retained without payout quote")
            log.warning("Proposal queue full; skipping quote requests for %s tick %s",symbol,tick_id)
        else:
            task=asyncio.create_task(self._capture_quotes(symbol,tick_id,int(tick["epoch"]),forecast_rows))
            self.quote_tasks.add(task)
            task.add_done_callback(self.quote_tasks.discard)
        return True

    async def _capture_quotes(self, symbol, tick_id, epoch, forecast_rows):
        unique=sorted({f.prediction for f,_ in forecast_rows})
        async def getq(d):
            try:
                async with self.proposal_semaphore:
                    return d, await self.proposals.quote(symbol,d,self.settings.paper_stake,1)
            except ProposalUnavailable as e:
                self._record_error(f"Proposal unavailable for {symbol} digit {d}: {e}")
                log.warning("No proposal for %s digit %s: %s",symbol,d,e); return d,None
        try:
            # Request actual Deriv proposal quotes for every candidate digit and
            # horizon over one WebSocket session to minimize quote latency.
            requests=[(symbol,d,self.settings.paper_stake,h) for d in unique for h in (1,2,3,4,5)]
            try:
                quotes=await self.proposals.quote_many(requests)
            except ProposalUnavailable as exc:
                self._record_error(f"Duration proposal batch unavailable for {symbol}: {exc}")
                quotes={}
            for f,seq in forecast_rows:
                for horizon in (1,2,3,4,5):
                    q=quotes.get((symbol,int(f.prediction),int(horizon)))
                    if not q: continue
                    try:
                        # Preserve legacy one-tick quote/paper path. Multi-tick
                        # quote/outcome pairs are tracked in their own immutable ledger.
                        if horizon == 1:
                            self.store.append_quote(symbol,f,seq,q["payout"],q["stake"],q["proposal_id"],q.get("spot_time"))
                            if self.paperbot:
                                self.paperbot.record(symbol,f,seq,tick_id,epoch,q["stake"],q["payout"],q["proposal_id"],q["spot_time"])
                        self.store.append_duration_quote(symbol,f,seq,tick_id,epoch,horizon,q["stake"],q["payout"],q["proposal_id"],q.get("spot_time"))
                    except Exception as exc:
                        self._record_error(f"Duration quote persistence failed for {symbol} forecast {seq} horizon {horizon}: {exc}")
                        log.exception("Could not persist duration quote")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._record_error(f"Quote capture task failed for {symbol} tick {tick_id}: {exc}")
            log.exception("Quote capture task failed")
    async def run_forever(self):
        delay=1
        try:
            while True:
                connected_at=None
                try:
                    self._set_connection_status("CONNECTING")
                    async with websockets.connect(self.settings.ws_url,ping_interval=20,ping_timeout=20,close_timeout=10) as ws:
                        connected_at=time.monotonic()
                        self.connection_started_monotonic=connected_at
                        self._set_connection_status("CONNECTED")
                        req_symbols={}; subscription_symbols={}
                        # Seed from the latest historical ticks without generating retrospective forecasts.
                        # This avoids waiting 1,000 live seconds before the research engine can start.
                        history_requests={200+index:symbol for index,symbol in enumerate(self.settings.symbols)}
                        history_status={symbol:"PENDING" for symbol in self.settings.symbols}
                        pending=set(history_requests)
                        for req_id,symbol in history_requests.items():
                            await ws.send(json.dumps({"ticks_history":symbol,"count":1000,"end":"latest","style":"ticks","req_id":req_id}))
                        while pending:
                            try:
                                raw_history=await asyncio.wait_for(ws.recv(),timeout=8)
                            except asyncio.TimeoutError:
                                self._record_error("Historical seed timed out; continuing with live ticks only")
                                break
                            symbol=None
                            try:
                                seed_msg=json.loads(raw_history,parse_float=Decimal)
                                seed_id=seed_msg.get("req_id")
                                if seed_id not in pending:
                                    continue
                                pending.remove(seed_id)
                                symbol=history_requests[seed_id]
                                if seed_msg.get("error"):
                                    history_status[symbol]="ERROR"
                                    self._update_symbol_status(symbol,history_seed_status="ERROR")
                                    error_message=seed_msg["error"].get("message","Deriv error")
                                    self._record_error(f"Historical seed failed for {symbol}: {error_message}",symbol)
                                    continue
                                hist=seed_msg.get("history") or {}
                                inserted=self._seed_history(symbol,hist,seed_msg.get("pip_size"))
                                history_status[symbol]="READY"
                                self._update_symbol_status(symbol,history_seed_status="READY")
                                log.info("Seeded %s historical ticks for %s",inserted,symbol)
                            except (json.JSONDecodeError,QuotePrecisionError,ValueError,KeyError,TypeError) as exc:
                                if symbol is not None:
                                    history_status[symbol]="ERROR"
                                    self._update_symbol_status(symbol,history_seed_status="ERROR")
                                self._record_error(f"Historical seed rejected: {exc}",symbol)
                                log.exception("Could not seed historical ticks")
                        for symbol in self.settings.symbols:
                            self.cumulative_counts[symbol]=list(self.store.digit_counts(symbol))
                            if symbol in pending:
                                history_status[symbol]="TIMEOUT"
                            if history_status[symbol]!="READY":
                                self._update_symbol_status(symbol,history_seed_status=history_status[symbol])
                        for index,symbol in enumerate(self.settings.symbols):
                            req_id=100+index; req_symbols[req_id]=symbol
                            self._update_symbol_status(
                                symbol,
                                subscription_status="SUBSCRIBING",
                            )
                            self._increment_symbol_status(symbol,"subscription_count")
                            await ws.send(json.dumps({"ticks":symbol,"subscribe":1,"req_id":req_id}))
                        # A normal WebSocket close is also a disconnect; route it through
                        # the same bounded backoff path as network errors.
                        async for raw in ws:
                            try:
                                msg=json.loads(raw,parse_float=Decimal)
                                if msg.get("error"):
                                    self._record_error(msg["error"].get("message","Deriv error"))
                                    log.error("Deriv stream error: %s",msg["error"])
                                    continue
                                tick=msg.get("tick")
                                if msg.get("msg_type")=="tick" and tick:
                                    req_id=msg.get("req_id")
                                    subscription_id=(msg.get("subscription") or {}).get("id")
                                    hint=(tick.get("symbol") or req_symbols.get(req_id)
                                          or (msg.get("echo_req") or {}).get("ticks")
                                          or subscription_symbols.get(subscription_id)
                                          or subscription_symbols.get(tick.get("id")))
                                    if hint:
                                        if subscription_id: subscription_symbols[subscription_id]=hint
                                        if tick.get("id"): subscription_symbols[tick["id"]]=hint
                                    try:
                                        await self._handle_tick(tick,hint)
                                    except (QuotePrecisionError,ValueError,KeyError,TypeError) as exc:
                                        self._record_error(f"Rejected malformed tick: {exc}",hint)
                                        log.exception("Rejected malformed tick: %s",exc)
                                    except Exception as exc:
                                        self._record_error(f"Tick processing failed: {exc}",hint)
                                        self._update_symbol_status(
                                            hint,
                                            analysis_status="ERROR",
                                            strategy_status="ERROR",
                                            signal_generation_status="ERROR",
                                        )
                                        log.exception("Tick processing failed")
                            except (json.JSONDecodeError,QuotePrecisionError,ValueError,KeyError,TypeError) as exc:
                                self._record_error(exc)
                                log.exception("Rejected malformed tick: %s",exc)
                    if connected_at is not None and time.monotonic()-connected_at>=60:
                        delay=1
                    self._set_connection_status("RECONNECTING","Deriv closed the tick stream",reconnect=True)
                    log.warning("Deriv closed the tick stream; reconnecting in %ss",delay)
                    await asyncio.sleep(delay)
                    delay=min(delay*2,30)
                except asyncio.CancelledError:
                    self._set_connection_status("DISCONNECTED")
                    raise
                except Exception as exc:
                    self._record_error(exc)
                    if connected_at is not None and time.monotonic()-connected_at>=60:
                        delay=1
                    self._set_connection_status("RECONNECTING",str(exc),reconnect=True)
                    log.exception("Market stream disconnected; reconnecting in %ss",delay)
                    await asyncio.sleep(delay)
                    delay=min(delay*2,30)
                finally:
                    self.connection_started_monotonic=None
        finally:
            if self.connection_status!="DISCONNECTED":
                self._set_connection_status("DISCONNECTED")
            for task in tuple(self.quote_tasks): task.cancel()
            if self.quote_tasks:
                await asyncio.gather(*tuple(self.quote_tasks),return_exceptions=True)
